A very basic CRUD application using ReactJS, ExpressJS and MongoDB.
